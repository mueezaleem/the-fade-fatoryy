const menuBtn = document.querySelector('.menu-btn');
const body = document.body;
const navLinks = document.querySelectorAll('.nav a');

menuBtn?.addEventListener('click', () => {
  const open = body.classList.toggle('menu-open');
  menuBtn.setAttribute('aria-expanded', String(open));
});

navLinks.forEach(link => link.addEventListener('click', () => {
  body.classList.remove('menu-open');
  menuBtn?.setAttribute('aria-expanded', 'false');
}));

document.getElementById('year').textContent = new Date().getFullYear();

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
