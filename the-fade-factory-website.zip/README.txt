THE FADE FACTORY — WEBSITE PACKAGE

Files
- index.html
- styles.css
- script.js

Business details used from Google Maps
- Name: The Fade Factory
- Category: Beauty salon
- Address: 24 Block, near Govt Girls High School, Satellite Town, Sargodha, 40100, Pakistan
- Phone / WhatsApp: +92 315 3151561
- Hours: 9:00 AM–11:30 PM daily
- Google Maps rating shown at build time: 5.0 (24 reviews)

Editing
1. Open index.html in any browser.
2. Edit text/content in index.html.
3. Edit colors/layout in styles.css.
4. Edit interactions in script.js.
5. WhatsApp links use wa.me/923153151561.
6. Gallery uses externally hosted Unsplash imagery; replace any image URL with your own photos when available.

Note
The service cards are generic inquiry categories to make the requested WhatsApp workflow functional. Exact service availability and pricing should be confirmed by the business.
